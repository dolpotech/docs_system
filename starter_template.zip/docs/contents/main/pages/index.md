#Starter `.md` file

Congratulations on making the template work.

Start making changes on the homepage by changing the contents in `index.md` file on the docs root directory.

Edit `nav` section of `mkdocs.yml` for adding pages on documentations.